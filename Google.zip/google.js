try {https://google.computerkoder.repl.co
	if (document.querySelector("title").innerHTML == "Error 400 (Bad Request)!!1") {
		document.querySelector("title").innerHTML = "No spaces"
		document.querySelector("body").innerHTML = "<p style='margin: 0px;'>Search the same thing without spaces</p>"
	}
	document.querySelector("svg").parentElement.innerHTML = "Dit Search Engine"
	document.querySelector("#lga").innerHTML = "Dit Search"
	document.querySelector("#hplogo").innerHTML = "Dit Search"
	document.querySelector(".lsb").value = "Dit Search"
	document.querySelector("#WqQANb").innerHTML = "<a href='https://go-http-template.xnotking.repl.co/'>Go HTTP</a><br><a href='https://msue.vercel.app'>Py Count To Five</a><br><a href='https://replit.com/@GLiQue/Repoolit?v=1'>Successor: Repoolit</a>"
	document.querySelector(".ds").innerHTML = '<input class="gLFyf gsfi" jsaction="paste:puy29d;" maxlength="2048" name="q" type="text" aria-autocomplete="both" aria-haspopup="false" autocapitalize="none" autocomplete="off" autocorrect="off" autofocus="" role="combobox" spellcheck="false" title="Buscar" value="" aria-label="Buscar" data-ved="0ahUKEwiEt5-y8p76AhUhmVwKHQTnCpAQ39UDCAY">'
	document.querySelector("title").innerHTML = "Dit Search Engine"
	document.querySelector("form").name = ""
	document.querySelectorAll("input")[0].name = "q"
	document.querySelectorAll("input")[0].value = ""
	console.log("Document loaded")
} catch (e) {
	console.log("This is dit search engine made by Sudais Usmani.")
}
<button onclick="myFunction()">Login</button>
<!DOCTYPE html>
<html>
<head>
	<title>Login Page</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<form>
		<h2>Login</h2>
		<label for="username">Username:</label>
		<input type="text" id="username" name="username" placeholder="Enter your username" required>
		<label for="password">Password:</label>
		<input type="password" id="password" name="password" placeholder="Enter your password" required>
		<input type="submit" value="Login">
	</form>
</body>
</html>